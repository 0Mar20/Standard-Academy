from django.urls import path

from . import views

app_name = 'form'
urlpatterns = [
    # ex: /polls/
 
    path('submit/', views.Submit, name="submit"),
    path('submit', views.Submit, name="submit"),
    

]