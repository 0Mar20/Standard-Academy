import datetime
from django.utils import timezone
from django.db import models
from django.contrib import admin

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.question_text
    
    def was_published_recently(self):
        now = timezone.now()
        return now - datetime.timedelta(days=1) <= self.pub_date <= now
    
    

class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)

    def __str__(self):
        return self.choice_text 


class Survey(models.Model):

    gender=models.CharField(max_length=200)  
    Age = models.CharField(max_length=200) 
    Nationality=models.CharField(max_length=200) 
    Gorvernate = models.CharField(max_length=200)
    Maritalstatus=models.CharField(max_length=200)
    Employmentstatus=models.CharField(max_length=200)
    children=models.CharField(max_length=200)
    Education =models.CharField(max_length=200)
    IncomePerMonth=models.CharField(max_length=200)

    class Meta:
        db_table = 'form_surey' 

class Survey2(models.Model):
    ChangeOfIncome =models.CharField(max_length=200)
    workDisrupted=models.CharField(max_length=200)
    reasonsDisruption=models.CharField(max_length=200)
    handling=models.CharField(max_length=200)
    strategies =models.CharField(max_length=200)
    StockpilingFood=models.CharField(max_length=200)
    priority = models.CharField(max_length=200)
    reason =  models.CharField(max_length=200)
    loyality = models.CharField(max_length=200)
    availabity = models.CharField(max_length=200)
    search =models.CharField(max_length=200) 

    class Meta:
      
        db_table = 'form_survey2'
