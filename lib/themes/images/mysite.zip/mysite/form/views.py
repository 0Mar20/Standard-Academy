from typing import ContextManager
from django import views
from django.shortcuts import render , redirect
from django.http import HttpResponse , HttpResponseRedirect
from .models import Survey , Survey2
from django.template import loader
from django.views import generic
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views.generic import ListView
from django.db.models import Count
from django.shortcuts import render


def home(request):
    return render(request , 'home.html' , {})


def examonline(request):
    M = Survey.objects.filter(gender='Male').count()/Survey.objects.count()
    F = Survey.objects.filter(gender='female').count()/Survey.objects.count()
    context = {
        'M':M,
        'F':F 
    }
    return render(request , 'index.html' , context)


def examonline2(request):
    return render(request,'index2.html',{})


def Submit(request):
    if request.method == 'POST' and 'b1' in request.POST:
        print("THIS IS POST")
        Name = request.POST.get('Name')
        gender = request.POST.get('gender')
        Age = request.POST.get('Age')
        Nationality = request.POST.get('Nationality')
        Gorvernate = request.POST.get('Gorvernate')
        Maritalstatus = request.POST.get('Maritalstatus')
        Employmentstatus = request.POST.get('Employmentstatus')
        children = request.POST.get('children')
        Education = request.POST.get('Education')
        IncomePerMonth = request.POST.get('IncomePerMonth')
        ins = Survey(gender=gender ,  Age = Age, Gorvernate = Gorvernate, Nationality = Nationality , Maritalstatus = Maritalstatus, Employmentstatus=Employmentstatus, children = children , Education = Education , IncomePerMonth = IncomePerMonth  )
        ins.save()
        return redirect('survey2/')
    
    if request.method == 'POST' and 'b2' in request.POST:
        ChangeOfIncome = request.POST.get('ChangeOfIncome')
        workDisrupted = request.POST.get('workDisrupted')
        reasonsDisruption = request.POST.getlist('reasonsDisruption')
        handling = request.POST.get('handling')
        strategies = request.POST.getlist('strategies')
        StockpilingFood = request.POST.get('StockpilingFood')
        loyality = request.POST.get('loyality')
        priority = request.POST.get('priority')
        reason = request.POST.get('reason')
        availabity = request.POST.get('availabity')
        
        search = request.POST.get('search')
        data = Survey2(ChangeOfIncome = ChangeOfIncome , workDisrupted =workDisrupted, reasonsDisruption=reasonsDisruption , handling = handling, strategies = strategies , StockpilingFood = StockpilingFood , loyality=loyality ,priority = priority, reason = reason, availabity= availabity, search = search )
        data.save()
   
    return render(request , 'thanks.html')
    

from django.db.models import Sum
from django.http import JsonResponse 

def population_chart(request):
    labels = []
    data = []

    queryset = Survey.objects.values('gender').annotate(country_population=Sum('population')).order_by('-country_population')
    for entry in queryset:
        labels.append(entry['country__name'])
        data.append(entry['country_population'])
    
    return JsonResponse(data={
        'labels': labels,
        'data': data,
    })

def chart_test(request): 
    if request.is_ajax:
        g = Survey.objects.values_list('gender',flat = True).distinct()
        g = list(g)
        gender =[]
        for i in g:
            l = Survey.objects.filter(gender=i).count()
            gender.append(l)
        context = {
        'gender':gender
        }       
    
        return render(request,'pie_chart.html',context)

    #return render(request,'pie_chart.html',{'gender':gender , 'nationality':nationality ,'Gorvernate':Gorvernate , 'Maritalstatus':Maritalstatus,'Employmentstatus':Employmentstatus,'children':children,'Education':Education , 'IncomePerMonth':IncomePerMonth,'workDisrupted':workDisrupted,'reasonsDisruption':reasonsDisruption,'handling':handling,'StockpilingFood':StockpilingFood,'loyality':loyality,'availabity':availabity,'search':search})




def index1(request):
    g = Survey.objects.values_list('gender',flat = True).distinct()
    g = list(g)
    gender =[]
    for i in g:
        l = Survey.objects.filter(gender=i).count()
        gender.append(l)

    n = Survey.objects.values_list('Nationality',flat = True).distinct()
    n = list(n)
    nationality =[]
    for i in n:
        na =  Survey.objects.filter(Nationality=i).count()
        nationality.append(na)

    Ga = Survey.objects.values_list('Gorvernate',flat = True).distinct()
    Ga = list(Ga)
    Gorvernate = []
    for i in Ga:
        Gav = Survey.objects.filter(Gorvernate=i).count()
        Gorvernate.append(Gav)

    
    MS = Survey.objects.values_list('Maritalstatus',flat = True).distinct()
    MS = list(MS)
    Maritalstatus = []
    for i in MS:
        mr = Survey.objects.filter(Maritalstatus=i).count()
        Maritalstatus.append(mr)


    E = Survey.objects.values_list('Employmentstatus',flat = True).distinct()
    E = list(E)
    Employmentstatus = []
    for i in E:
        ES = Survey.objects.filter(Employmentstatus=i).count()
        Employmentstatus.append(ES)

    ch = Survey.objects.values_list('children',flat = True).distinct()
    ch= list(ch)
    children = []
    for i in ch:
        chi = Survey.objects.filter(children=i).count()
        children.append(chi)


    Ed = Survey.objects.values_list('Education',flat = True).distinct()
    Ed = list(Ed)
    Education= []
    for i in Ed:
        Edu = Survey.objects.filter(Education=i).count()
        Education.append(Edu)
    

    IPM = Survey.objects.values_list('IncomePerMonth',flat = True).distinct()
    IPM = list(IPM)
    IncomePerMonth = []
    for i in IPM:
        IM = Survey.objects.filter(IncomePerMonth=i).count()
        IncomePerMonth.append(IM)

    return render(request , 'index1.html' ,{'gender':gender , 'nationality':nationality ,'Gorvernate':Gorvernate , 'Maritalstatus':Maritalstatus,'Employmentstatus':Employmentstatus,'children':children,'Education':Education , 'IncomePerMonth':IncomePerMonth,} )




def index22(request):
    return render(request , 'index22.html' ,{} )    

