from form import views
from django.contrib import admin
from django.urls import include, path
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path('form/', include('form.urls'),name='form'),
    path('admin/', admin.site.urls),
    path('' , views.home , name='home'),
    path('submit',views.Submit),
    path('submit' , views.Submit),
    path('pie-chart/', views.chart_test, name='pie-chart'),
    path('survey/', views.index1, name='index1'),
    path('survey2/', views.index22, name='index22'),    
         

    
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)